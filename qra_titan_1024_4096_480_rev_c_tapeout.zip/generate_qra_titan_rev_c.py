import struct
import math
from collections import Counter

def gds_real8_encode(val):
    if val == 0.0:
        return b'\x00' * 8
    sign = 0x80 if val < 0 else 0x00
    val = abs(val)
    exp = 0
    while val >= 1.0:
        val /= 16.0
        exp += 1
    while val < 1.0 / 16.0:
        val *= 16.0
        exp -= 1
    mant = int(round(val * (2 ** 56)))
    if mant >= (2 ** 56):
        mant //= 16
        exp += 1
    first_byte = sign | ((exp + 64) & 0x7F)
    return bytes([first_byte]) + mant.to_bytes(7, 'big')

def rec(rec_type, data_type, payload=b''):
    length = 4 + len(payload)
    return struct.pack('>HBB', length, rec_type, data_type) + payload

def rec_str(rec_type, text):
    b = text.encode('ascii')
    if len(b) % 2 == 1:
        b += b'\x00'
    return rec(rec_type, 0x06, b)

def rec_i2(rec_type, *vals):
    return rec(rec_type, 0x02, struct.pack(f'>{len(vals)}h', *vals))

def rec_i4(rec_type, *vals):
    return rec(rec_type, 0x03, struct.pack(f'>{len(vals)}i', *vals))

def make_rect(layer, x0, y0, x1, y1, datatype=0):
    pts = [int(round(x0)), int(round(y0)),
           int(round(x1)), int(round(y0)),
           int(round(x1)), int(round(y1)),
           int(round(x0)), int(round(y1)),
           int(round(x0)), int(round(y0))]
    return (
        rec(0x08, 0x00) +
        rec_i2(0x0D, layer) +
        rec_i2(0x0E, datatype) +
        rec_i4(0x10, *pts) +
        rec(0x11, 0x00)
    )

def make_poly(layer, pts_xy, datatype=0):
    flat = []
    for x, y in pts_xy:
        flat.extend([int(round(x)), int(round(y))])
    if pts_xy[0] != pts_xy[-1]:
        flat.extend([int(round(pts_xy[0][0])), int(round(pts_xy[0][1]))])
    return (
        rec(0x08, 0x00) +
        rec_i2(0x0D, layer) +
        rec_i2(0x0E, datatype) +
        rec_i4(0x10, *flat) +
        rec(0x11, 0x00)
    )

def make_text(layer, x, y, text, texttype=0):
    return (
        rec(0x0C, 0x00) +
        rec_i2(0x0D, layer) +
        rec_i2(0x16, texttype) +
        rec_i4(0x10, int(round(x)), int(round(y))) +
        rec_str(0x19, text) +
        rec(0x11, 0x00)
    )

def make_octagon(cx, cy, radius_nm):
    pts = []
    for i in range(8):
        ang = math.radians(22.5 + 45.0 * i)
        pts.append((cx + radius_nm * math.cos(ang), cy + radius_nm * math.sin(ang)))
    pts.append(pts[0])
    return pts

def generate_rev_c(out_path="qra_titan_1024_4096_480_rev_c_tapeout.gds"):
    UM = 1000
    MM = 1000000

    chunks = []
    ts = (2026, 11, 26, 13, 35, 0, 2026, 11, 26, 13, 35, 0)

    chunks.append(rec_i2(0x00, 600))
    chunks.append(rec_i2(0x01, *ts))
    chunks.append(rec_str(0x02, "QRA_TITAN_1024_REV_C_LIB"))
    chunks.append(rec(0x03, 0x05, gds_real8_encode(0.001) + gds_real8_encode(1e-9)))
    chunks.append(rec_i2(0x05, *ts))
    chunks.append(rec_str(0x06, "QRA_TITAN_TOP_32MM_REVC"))

    # Layer 10: 32mm x 32mm Seal Ring (180 um wide) + 8 Alignment Crosses
    DIE = 32 * MM
    SR = 180 * UM
    chunks.append(make_rect(10, 0, 0, DIE, SR))
    chunks.append(make_rect(10, 0, DIE - SR, DIE, DIE))
    chunks.append(make_rect(10, 0, SR, SR, DIE - SR))
    chunks.append(make_rect(10, DIE - SR, SR, DIE, DIE - SR))

    fid_pts = [
        (600*UM, 600*UM), (DIE - 600*UM, 600*UM),
        (600*UM, DIE - 600*UM), (DIE - 600*UM, DIE - 600*UM),
        (16*MM, 600*UM), (16*MM, DIE - 600*UM),
        (600*UM, 16*MM), (DIE - 600*UM, 16*MM),
    ]
    for fx, fy in fid_pts:
        chunks.append(make_rect(10, fx - 160*UM, fy - 30*UM, fx + 160*UM, fy + 30*UM))
        chunks.append(make_rect(10, fx - 30*UM, fy - 160*UM, fx + 30*UM, fy + 160*UM))

    # Layer 7: 480 Perimeter Bond Pads (120 per side, 240 um pitch)
    pad_start = 1645 * UM
    pad_pitch = 240 * UM
    for i in range(120):
        x0 = pad_start + i * pad_pitch
        chunks.append(make_rect(7, x0, 360*UM, x0 + 150*UM, 840*UM))
        chunks.append(make_rect(7, x0, DIE - 840*UM, x0 + 150*UM, DIE - 360*UM))
        y0 = pad_start + i * pad_pitch
        chunks.append(make_rect(7, 360*UM, y0, 840*UM, y0 + 150*UM))
        chunks.append(make_rect(7, DIE - 840*UM, y0, DIE - 360*UM, y0 + 150*UM))

    # Layer 6: 8 Cryo-AI Control & QEC Blocks (6.4 mm x 2.4 mm) + Layer 3 Control Buses
    cryo_x = [2.4*MM, 9.3*MM, 16.3*MM, 23.2*MM]
    cryo_labels_n = ["CRYO_AI_QEC_CNN_NW", "CRYO_AI_FLUX_DAC_N1", "CRYO_AI_FLUX_DAC_N2", "CRYO_AI_BERRY_PLL_NE"]
    cryo_labels_s = ["CRYO_AI_QEC_CNN_SW", "CRYO_AI_FLUX_DAC_S1", "CRYO_AI_FLUX_DAC_S2", "CRYO_AI_RG_SEQ_SE"]

    for idx, bx in enumerate(cryo_x):
        chunks.append(make_rect(6, bx, 27.6*MM, bx + 6.4*MM, 30.0*MM))
        chunks.append(make_text(10, bx + 3.2*MM, 28.8*MM, cryo_labels_n[idx]))
        chunks.append(make_rect(6, bx, 2.0*MM, bx + 6.4*MM, 4.4*MM))
        chunks.append(make_text(10, bx + 3.2*MM, 3.2*MM, cryo_labels_s[idx]))

        for bus in range(8):
            tx = bx + 0.7*MM + bus * 0.7*MM
            chunks.append(make_rect(3, tx, 26.05*MM, tx + 24*UM, 27.6*MM))
            chunks.append(make_rect(3, tx, 4.4*MM, tx + 24*UM, 5.55*MM))

    # 16 Sectors (4x4 grid, 64 qubits per sector = 1024 Heavy-Xmon qubits)
    sector_xs = [3.55*MM, 9.95*MM, 16.35*MM, 22.75*MM]
    sector_ys = [5.55*MM, 10.95*MM, 16.35*MM, 21.75*MM]
    sec_w, sec_h = 5.3*MM, 4.3*MM

    sector_idx = 1
    for r, sy in enumerate(sector_ys):
        for c, sx in enumerate(sector_xs):
            chunks.append(make_rect(1, sx, sy, sx + sec_w, sy + sec_h))
            cx, cy = sx + sec_w / 2.0, sy + sec_h / 2.0
            chunks.append(make_poly(1, make_octagon(cx, cy, 950*UM)))

            q_x0 = sx + 410*UM
            q_y0 = sy + 395*UM
            qx_pitch = 600*UM
            qy_pitch = 480*UM

            for qr in range(8):
                for qc in range(8):
                    qx = q_x0 + qc * qx_pitch
                    qy = q_y0 + qr * qy_pitch
                    chunks.append(make_rect(1, qx, qy, qx + 110*UM, qy + 150*UM))
                    chunks.append(make_rect(1, qx + 170*UM, qy, qx + 280*UM, qy + 150*UM))
                    chunks.append(make_rect(2, qx + 110*UM, qy + 50*UM, qx + 170*UM, qy + 100*UM))
                    if (qr + qc) % 2 == 0:
                        chunks.append(make_rect(3, qx + 95*UM, qy + 160*UM, qx + 185*UM, qy + 195*UM))

            for ci in range(4):
                bx = sx + 850*UM + ci * 1200*UM
                chunks.append(make_rect(2, bx, sy + sec_h - 140*UM, bx + 90*UM, sy + sec_h - 50*UM))

            for pi in range(4):
                px = sx + 750*UM + pi * 1200*UM
                chunks.append(make_rect(3, px, sy + 120*UM, px + 170*UM, sy + 160*UM))
                chunks.append(make_rect(3, px + 71*UM, sy + 60*UM, px + 99*UM, sy + 88*UM))

            chunks.append(make_text(10, sx + sec_w / 2.0, sy + sec_h - 200*UM, f"SECTOR_{sector_idx:02d}_64Q"))
            sector_idx += 1

    # Rev C: 48 Inter-Sector Quantum-Link Coupler Buses on Layer 2
    for r, sy in enumerate(sector_ys):
        for c in range(3):
            gx0 = sector_xs[c] + sec_w
            gx1 = sector_xs[c+1]
            for offset in [1.4*MM, 2.9*MM]:
                chunks.append(make_rect(2, gx0, sy + offset, gx1, sy + offset + 40*UM))
    for c, sx in enumerate(sector_xs):
        for r in range(3):
            gy0 = sector_ys[r] + sec_h
            gy1 = sector_ys[r+1]
            for offset in [1.7*MM, 3.6*MM]:
                chunks.append(make_rect(2, sx + offset, gy0, sx + offset + 40*UM, gy1))

    # Layer 1: Perimeter Fanout Routing Traces
    for i in range(48):
        trace_len = (320 + (i % 12) * 65) * UM
        pos_coord = 3.2*MM + i * 540*UM
        chunks.append(make_rect(1, pos_coord, 840*UM, pos_coord + 10*UM, 840*UM + trace_len))
        chunks.append(make_rect(1, pos_coord, DIE - 840*UM - trace_len, pos_coord + 10*UM, DIE - 840*UM))
        chunks.append(make_rect(1, 840*UM, pos_coord, 840*UM + trace_len, pos_coord + 10*UM))
        chunks.append(make_rect(1, DIE - 840*UM - trace_len, pos_coord, DIE - 840*UM, pos_coord + 10*UM))

    # Layer 4: 4,096 Flip-Chip Indium Bumps / TSVs (64 x 64)
    nx4, ny4 = 64, 64
    x4_min, x4_max = 3155*UM, 28755*UM
    y4_min, y4_max = 5155*UM, 26755*UM
    dx4 = (x4_max - x4_min) / (nx4 - 1)
    dy4 = (y4_max - y4_min) / (ny4 - 1)
    for iy in range(ny4):
        y0 = y4_min + iy * dy4
        for ix in range(nx4):
            x0 = x4_min + ix * dx4
            chunks.append(make_rect(4, x0, y0, x0 + 90*UM, y0 + 90*UM))

    # Layer 5: 4,624 Grounding Vias / Airbridge Anchors (68 x 68)
    nx5, ny5 = 68, 68
    x5_min, x5_max = 2165*UM, 29765*UM
    y5_min, y5_max = 4565*UM, 27365*UM
    dx5 = (x5_max - x5_min) / (nx5 - 1)
    dy5 = (y5_max - y5_min) / (ny5 - 1)
    for iy in range(ny5):
        y0 = y5_min + iy * dy5
        for ix in range(nx5):
            x0 = x5_min + ix * dx5
            chunks.append(make_rect(5, x0, y0, x0 + 70*UM, y0 + 70*UM))

    # Top-level Labels
    chunks.append(make_text(10, 16.0*MM, 30.6*MM, "QRA_TITAN_1024_4096_480_REV_C_ROUTED"))
    chunks.append(make_text(10, 16.0*MM, 16.0*MM, "1024Q_16x64_HEAVY_XMON_CORE"))

    chunks.append(rec(0x07, 0x00))
    chunks.append(rec(0x04, 0x00))

    gds_bytes = b"".join(chunks)
    with open(out_path, "wb") as f:
        f.write(gds_bytes)
    return out_path, len(gds_bytes)

if __name__ == "__main__":
    p, sz = generate_rev_c()
    print(f"Wrote {p} ({sz:,} bytes)")
